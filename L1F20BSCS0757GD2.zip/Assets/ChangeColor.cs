using UnityEngine;
using System.Collections;

public class CollisionColorChange : MonoBehaviour
{

    public Color redcolor;
    public Color bluecolor;


    void OnCollisionEnter(Collision other)
    {
        if (other.transform.tag == "Red")
        {
            transform.GetComponent<Renderer>().material.color = redcolor;
        }

        if (other.transform.tag == "Blue")
        {
            transform.GetComponent<Renderer>().material.color = bluecolor;
        }
    }
}